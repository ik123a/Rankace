// Rankace SEO Assistant - Content Script
// Live On-Page DOM Auditor & Visual Bounding Box Inspector

(function () {
  if (window.__RANKACE_CONTENT_SCRIPT_LOADED__) return;
  window.__RANKACE_CONTENT_SCRIPT_LOADED__ = true;

  console.log("%c⚡ Rankace SEO Assistant Loaded", "color: #3b82f6; font-weight: bold; font-size: 12px;");

  let activeHighlightBoxes = [];
  let cachedAuditData = null;
  let allHighlighted = false;
  let isInspectionEnabled = true;

  const vitalsState = { lcpMs: null, cls: 0 };

  /** Observe live Core Web Vitals metrics (LCP and CLS) when supported. */
  function initVitalsObservers() {
    if (typeof PerformanceObserver !== "function") return;
    try {
      const lcpObs = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        if (entries.length) {
          vitalsState.lcpMs = Math.round(entries[entries.length - 1].startTime);
        }
      });
      lcpObs.observe({ type: "largest-contentful-paint", buffered: true });
    } catch (e) { /* unsupported */ }

    try {
      const clsObs = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (!entry.hadRecentInput && typeof entry.value === "number") {
            vitalsState.cls = Math.round((vitalsState.cls + entry.value) * 1000) / 1000;
          }
        }
      });
      clsObs.observe({ type: "layout-shift", buffered: true });
    } catch (e) { /* unsupported */ }
  }
  initVitalsObservers();

  /** Snapshot current LCP, CLS, TTFB, and DOMContentLoaded timing in ms. */
  function getPageVitals() {
    let ttfbMs = null;
    let dclMs = null;
    try {
      const nav = performance.getEntriesByType && performance.getEntriesByType("navigation")[0];
      if (nav) {
        if (typeof nav.responseStart === "number" && nav.responseStart > 0) {
          ttfbMs = Math.round(nav.responseStart);
        }
        if (typeof nav.domContentLoadedEventEnd === "number" && nav.domContentLoadedEventEnd > 0) {
          dclMs = Math.round(nav.domContentLoadedEventEnd);
        }
      }
    } catch (e) { /* ignore */ }
    return {
      lcpMs: vitalsState.lcpMs,
      cls: vitalsState.cls,
      ttfbMs,
      domContentLoadedMs: dclMs
    };
  }

  const SCHEMA_RECOMMENDED_FIELDS = {
    Article: ["headline", "author", "datePublished", "image"],
    NewsArticle: ["headline", "author", "datePublished", "image"],
    BlogPosting: ["headline", "author", "datePublished", "image"],
    Organization: ["name", "url", "logo"],
    WebPage: ["name", "url", "description"],
    Product: ["name", "offers"],
    FAQPage: ["mainEntity"],
    BreadcrumbList: ["itemListElement"]
  };

  // -------------------------------------------------------------
  // 1. LIVE ON-PAGE AUDIT ENGINE
  // -------------------------------------------------------------
  function runLiveAudit() {
    const issues = [];
    const elementsToHighlight = [];
    let score = 100;

    // A. Title Tag
    const title = document.title ? document.title.trim() : "";
    const titleLen = title.length;
    if (!title) {
      issues.push({
        id: "title_missing",
        category: "Metadata",
        severity: "critical",
        title: "Missing <title> Tag",
        message: "This page has no title tag. Page titles are critical for search engine rankings and CTR.",
        recommendation: "Add a descriptive <title> tag between 50-60 characters.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 20;
    } else if (titleLen < 30) {
      issues.push({
        id: "title_too_short",
        category: "Metadata",
        severity: "warning",
        title: "Title Tag Too Short",
        message: `Title is only ${titleLen} characters. Search engines prefer 50-60 characters.`,
        recommendation: "Expand the title with primary keywords and brand value.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 5;
    } else if (titleLen > 65) {
      issues.push({
        id: "title_too_long",
        category: "Metadata",
        severity: "warning",
        title: "Title Tag Likely Truncated",
        message: `Title is ${titleLen} characters and will be cut off with an ellipsis in Google SERPs.`,
        recommendation: "Shorten title to under 60 characters to avoid truncation.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 5;
    }

    // B. Meta Description
    const metaDescEl = document.querySelector('meta[name="description"], meta[property="og:description"]');
    const metaDesc = metaDescEl ? (metaDescEl.getAttribute("content") || "").trim() : "";
    const descLen = metaDesc.length;
    if (!metaDesc) {
      issues.push({
        id: "desc_missing",
        category: "Metadata",
        severity: "critical",
        title: "Missing Meta Description",
        message: "No meta description found. Search engines will auto-generate snippets from page text.",
        recommendation: "Add a compelling meta description between 120-160 characters.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 15;
    } else if (descLen < 80) {
      issues.push({
        id: "desc_too_short",
        category: "Metadata",
        severity: "warning",
        title: "Meta Description Too Short",
        message: `Description is only ${descLen} characters (recommended 120-160).`,
        recommendation: "Expand description with clear user benefits and a call-to-action.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 5;
    } else if (descLen > 165) {
      issues.push({
        id: "desc_too_long",
        category: "Metadata",
        severity: "warning",
        title: "Meta Description May Truncate",
        message: `Description is ${descLen} characters and may be clipped on mobile SERPs.`,
        recommendation: "Keep meta description between 120 and 160 characters.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 4;
    }

    // C. Canonical Tag
    const canonicalEl = document.querySelector('link[rel="canonical"]');
    const canonical = canonicalEl ? canonicalEl.getAttribute("href") : "";
    if (!canonical) {
      issues.push({
        id: "canonical_missing",
        category: "Metadata",
        severity: "warning",
        title: "Missing Canonical Tag",
        message: "Missing rel='canonical' tag can lead to duplicate content consolidation issues.",
        recommendation: "Specify <link rel='canonical' href='...'> pointing to the primary URL.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 6;
    }

    // D. Headings Structure (H1, H2, H3)
    const h1s = Array.from(document.querySelectorAll("h1"));
    if (h1s.length === 0) {
      issues.push({
        id: "h1_missing",
        category: "Headings",
        severity: "critical",
        title: "Missing <h1> Heading",
        message: "No H1 heading found on this page. Search engines use H1 to understand the primary page topic.",
        recommendation: "Add a single, keyword-focused <h1> heading at the top of your main content.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 15;
    } else if (h1s.length > 1) {
      h1s.slice(1).forEach((el, idx) => {
        const sel = getElementPath(el);
        issues.push({
          id: `h1_multiple_${idx}`,
          category: "Headings",
          severity: "warning",
          title: `Multiple <h1> Headings Found (${h1s.length} total)`,
          message: `Secondary <h1> found: "${(el.textContent || '').trim().substring(0, 45)}...".`,
          recommendation: "Change this heading to an <h2> or <h3> to maintain a clean semantic hierarchy.",
          targetSelector: sel,
          domElement: el
        });
      });
      score -= 8;
    } else {
      const h1Text = (h1s[0].textContent || "").trim();
      if (!h1Text) {
        issues.push({
          id: "h1_empty",
          category: "Headings",
          severity: "critical",
          title: "Empty <h1> Heading",
          message: "The <h1> heading exists but contains no visible text content.",
          recommendation: "Add descriptive text to your primary heading.",
          targetSelector: getElementPath(h1s[0]),
          domElement: h1s[0]
        });
        score -= 12;
      }
    }

    const h2s = Array.from(document.querySelectorAll("h2"));
    const h3s = Array.from(document.querySelectorAll("h3"));

    // E. Images & Alt Text Inspector (Only audit real, visible, measurable content images)
    const images = Array.from(document.querySelectorAll("img"));
    let missingAltCount = 0;
    images.forEach((img, idx) => {
      // 1. Must be rendered in the document layout
      if (!img.isConnected) return;
      const style = window.getComputedStyle(img);
      if (style.display === "none" || style.visibility === "hidden" || parseFloat(style.opacity || "1") === 0) return;
      if (img.offsetParent === null && style.position !== "fixed") return;

      const rect = img.getBoundingClientRect();
      // Must have visible content dimensions (ignore 0x0 images, tracking pixels, tiny icons < 24px)
      if (rect.width < 24 || rect.height < 24) return;

      // 2. Ignore decorative images with role="presentation", role="none", or aria-hidden="true"
      if (img.getAttribute("role") === "presentation" || img.getAttribute("role") === "none" || img.getAttribute("aria-hidden") === "true") return;

      // 3. Ignore images inside <figure> that already have a descriptive <figcaption>
      const figure = img.closest("figure");
      if (figure && figure.querySelector("figcaption") && (figure.querySelector("figcaption").textContent || "").trim().length > 3) return;

      // 4. Check aria-label / aria-labelledby fallback
      const ariaLabel = (img.getAttribute("aria-label") || "").trim();
      const ariaLabelledby = img.getAttribute("aria-labelledby");
      if (ariaLabel || ariaLabelledby) return;

      // 5. Check alt attribute
      const hasAlt = img.hasAttribute("alt");
      const altText = (img.getAttribute("alt") || "").trim();

      if (!hasAlt || altText === "") {
        missingAltCount++;
        const sel = getElementPath(img);
        if (!sel) return;

        issues.push({
          id: `img_alt_${idx}`,
          category: "Images",
          severity: "critical",
          title: `Image Missing 'alt' Description`,
          message: `The image is loaded and visible, but lacks an 'alt' text description in its HTML <img> tag. Search engines (like Google) cannot read the text or diagram inside this graphic without an alt attribute.`,
          recommendation: "Add descriptive alt='...' text (e.g. alt='Playbook containment workflow diagram') to the <img> tag.",
          targetSelector: sel,
          domElement: img
        });
      }
    });
    if (missingAltCount > 0) {
      score -= Math.min(missingAltCount * 4, 20);
    }

    // F. Hyperlinks & Anchor Text Inspector
    const links = Array.from(document.querySelectorAll("a[href]"));
    let emptyLinkCount = 0;
    links.forEach((a, idx) => {
      if (!a.isConnected) return;
      const style = window.getComputedStyle(a);
      if (style.display === "none" || style.visibility === "hidden" || parseFloat(style.opacity || "1") === 0) return;
      if (a.offsetParent === null && style.position !== "fixed") return;

      const rect = a.getBoundingClientRect();
      if (rect.width < 12 || rect.height < 12) return;

      const href = (a.getAttribute("href") || "").trim();
      if (href === "" || href === "#" || href.startsWith("javascript:")) return;

      const text = (a.textContent || "").trim();
      const hasImgWithAlt = a.querySelector("img[alt]:not([alt=''])");
      const ariaLabel = (a.getAttribute("aria-label") || "").trim();
      if (ariaLabel || hasImgWithAlt) return;

      if (!text) {
        emptyLinkCount++;
        const sel = getElementPath(a);
        if (!sel) return;
        issues.push({
          id: `link_empty_${idx}`,
          category: "Links",
          severity: "warning",
          title: "Empty Link Anchor Text",
          message: "Hyperlink has no visible text or image alt. Search engines cannot infer destination context.",
          recommendation: "Provide clear, descriptive anchor text indicating where the link navigates.",
          targetSelector: sel,
          domElement: a
        });
      } else if (/^(click here|read more|learn more|here|more|link)$/i.test(text)) {
        const sel = getElementPath(a);
        if (!sel) return;
        issues.push({
          id: `link_generic_${idx}`,
          category: "Links",
          severity: "info",
          title: `Non-Descriptive Anchor: "${text}"`,
          message: "Generic anchor text gives zero keyword context to search crawlers.",
          recommendation: "Replace generic text with contextual keywords describing the target topic.",
          targetSelector: sel,
          domElement: a
        });
      }
    });
    if (emptyLinkCount > 0) {
      score -= Math.min(emptyLinkCount * 3, 15);
    }

    // G. Content Density & Word Count
    const bodyText = (document.body ? document.body.innerText || "" : "").replace(/\s+/g, " ").trim();
    const wordCount = bodyText ? bodyText.split(" ").length : 0;
    if (wordCount < 250) {
      issues.push({
        id: "content_thin",
        category: "Content",
        severity: "critical",
        title: `Thin Content (${wordCount} words)`,
        message: "Page has fewer than 250 words. Search engines may consider this low-value or thin content.",
        recommendation: "Expand the page with comprehensive, helpful information addressing user search queries.",
        targetSelector: null,
        isPageLevel: true
      });
      score -= 15;
    }

    // =============================================================
    // H–O. DETAILED PAGE FACTS AND THE CHECKS THEY ENABLE
    //
    // Everything below is read from the live DOM and reported in the side
    // panel. Nothing is inferred: a field is either present in the document
    // or marked absent. Checks whose finding is advisory (social previews,
    // structured data, image dimensions) emit `info` issues, which carry no
    // score weight, so a page cannot be marked unhealthy for lacking a
    // Twitter card.
    // =============================================================

    function metaContent(selector) {
      const el = document.querySelector(selector);
      return el ? (el.getAttribute("content") || "").trim() : "";
    }

    // H. Indexability -------------------------------------------------
    const robotsMeta = [
      metaContent('meta[name="robots" i]'),
      metaContent('meta[name="googlebot" i]')
    ]
      .filter(Boolean)
      .join(",")
      .toLowerCase();
    const isNoindex = /(^|[,\s])noindex([,\s]|$)/.test(robotsMeta) || /(^|[,\s])none([,\s]|$)/.test(robotsMeta);
    if (isNoindex) {
      issues.push({
        id: "meta_noindex",
        category: "Indexability",
        severity: "critical",
        title: "Page Is Set To Noindex",
        message: `Robots meta is "${robotsMeta}". Search engines are told to drop this URL from the index, so it cannot rank regardless of content quality.`,
        recommendation: "Remove 'noindex' from the robots meta if this page is meant to appear in search.",
        targetSelector: null,
        isPageLevel: true
      });
    }

    // I. Canonical safety ---------------------------------------------
    let canonicalSelf = null;
    if (canonical) {
      try {
        const canonicalUrl = new URL(canonical, location.href);
        canonicalSelf = canonicalUrl.hostname === location.hostname;
        // Only a real page can contradict its own canonical. On about:blank --
        // and in any document without an origin -- location.hostname is "",
        // so every canonical would be reported as cross-domain.
        if (location.hostname && !canonicalSelf) {
          issues.push({
            id: "canonical_cross_domain",
            category: "Metadata",
            severity: "warning",
            title: "Canonical Points To Another Domain",
            message: `rel=canonical targets ${canonicalUrl.hostname}, not ${location.hostname}. This page is asking Google to credit a different site.`,
            recommendation: "Confirm this is intentional; otherwise make the canonical self-referencing.",
            targetSelector: null,
            isPageLevel: true
          });
        }
      } catch (err) {
        canonicalSelf = false;
      }
    }

    const refreshMeta = document.querySelector('meta[http-equiv="refresh" i]');
    if (refreshMeta) {
      issues.push({
        id: "meta_refresh",
        category: "Technical",
        severity: "warning",
        title: "Meta Refresh Redirect",
        message: `This page redirects with <meta http-equiv="refresh">: "${(refreshMeta.getAttribute("content") || "").trim()}". Crawlers treat it as a soft redirect.`,
        recommendation: "Use a real 301 redirect at the server instead of a meta refresh.",
        targetSelector: null,
        isPageLevel: true
      });
    }

    // J. Heading outline (document order, H1–H6) ----------------------
    const headingNodes = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6"));
    const headingCounts = { h1: 0, h2: 0, h3: 0, h4: 0, h5: 0, h6: 0 };
    headingNodes.forEach((node) => {
      const level = node.tagName.toLowerCase();
      if (headingCounts[level] !== undefined) headingCounts[level] += 1;
    });
    const headingOutline = headingNodes.slice(0, 60).map((node) => ({
      level: Number(node.tagName.substring(1)),
      text: (node.textContent || "").replace(/\s+/g, " ").trim().slice(0, 110)
    }));

    // A skipped level (h2 straight to h4) breaks the document outline that
    // assistive tech and crawlers use to derive page structure. Reported once
    // per page with the first offending pair rather than per heading.
    let skippedLevel = null;
    for (let i = 1; i < headingOutline.length; i += 1) {
      if (headingOutline[i].level - headingOutline[i - 1].level > 1) {
        skippedLevel = headingOutline[i];
        break;
      }
    }
    if (skippedLevel) {
      issues.push({
        id: "heading_skip",
        category: "Headings",
        severity: "info",
        title: `Heading Level Skips To H${skippedLevel.level}`,
        message: `"${skippedLevel.text || "(empty heading)"}" follows a heading more than one level above it.`,
        recommendation: "Nest headings one level at a time (h2 → h3) so the outline stays machine-readable.",
        targetSelector: null,
        isPageLevel: true
      });
    }

    // K. Social metadata ----------------------------------------------
    const ogTitle = metaContent('meta[property="og:title"]');
    const ogDescription = metaContent('meta[property="og:description"]');
    const ogImage = metaContent('meta[property="og:image"]');
    const ogType = metaContent('meta[property="og:type"]');
    const ogUrl = metaContent('meta[property="og:url"]');
    const twitterCard = metaContent('meta[name="twitter:card"]');
    const twitterTitle = metaContent('meta[name="twitter:title"]');
    const twitterDescription = metaContent('meta[name="twitter:description"]');
    const twitterImage = metaContent('meta[name="twitter:image"]');

    const missingSocial = [];
    if (!ogTitle) missingSocial.push("og:title");
    if (!ogDescription) missingSocial.push("og:description");
    if (!ogImage) missingSocial.push("og:image");
    if (!twitterCard) missingSocial.push("twitter:card");
    if (missingSocial.length > 0) {
      issues.push({
        id: "social_incomplete",
        category: "Social",
        severity: "info",
        title: `Incomplete Social Preview (${missingSocial.length} missing)`,
        message: `Missing: ${missingSocial.join(", ")}. Shared links fall back to the page title and the platform's placeholder image.`,
        recommendation: "Add og:title, og:description and a 1200×630 og:image so shares render with control.",
        targetSelector: null,
        isPageLevel: true
      });
    }

    // L. Structured data ---------------------------------------------
    const jsonLdBlocks = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
    const jsonLdTypes = [];
    const schemaItems = [];
    let invalidJsonLd = 0;
    jsonLdBlocks.forEach((block, blockIndex) => {
      const raw = block.textContent || "";
      if (!raw.trim()) return;
      try {
        const parsed = JSON.parse(raw);
        const blockTypes = [];
        const missingFields = new Set();
        const blockKeys = new Set();
        const visit = (node) => {
          if (!node || typeof node !== "object") return;
          if (Array.isArray(node)) {
            node.forEach(visit);
            return;
          }
          Object.keys(node).forEach((k) => {
            if (!k.startsWith("@")) blockKeys.add(k);
          });
          const type = node["@type"];
          const nodeTypes = typeof type === "string"
            ? [type]
            : Array.isArray(type)
              ? type.filter((t) => typeof t === "string")
              : [];
          nodeTypes.forEach((t) => {
            jsonLdTypes.push(t);
            blockTypes.push(t);
            const expected = SCHEMA_RECOMMENDED_FIELDS[t] || [];
            expected.forEach((field) => {
              const val = node[field];
              if (val === undefined || val === null || val === "" || (Array.isArray(val) && !val.length)) {
                missingFields.add(`${t}.${field}`);
              }
            });
          });
          if (node["@graph"] && Array.isArray(node["@graph"])) node["@graph"].forEach(visit);
        };
        visit(parsed);
        if (schemaItems.length < 6) {
          schemaItems.push({
            index: blockIndex + 1,
            valid: true,
            types: Array.from(new Set(blockTypes)),
            keys: Array.from(blockKeys).slice(0, 6),
            missing: Array.from(missingFields).slice(0, 4)
          });
        }
      } catch (err) {
        invalidJsonLd += 1;
        if (schemaItems.length < 6) {
          schemaItems.push({
            index: blockIndex + 1,
            valid: false,
            types: [],
            keys: [],
            missing: ["Invalid JSON syntax"]
          });
        }
      }
    });
    const microdataItems = document.querySelectorAll("[itemscope][itemtype]").length;

    if (invalidJsonLd > 0) {
      issues.push({
        id: "schema_invalid",
        category: "Schema",
        severity: "warning",
        title: `Invalid JSON-LD (${invalidJsonLd} block${invalidJsonLd === 1 ? "" : "s"})`,
        message: "A structured-data block is not valid JSON, so search engines ignore it entirely.",
        recommendation: "Validate the JSON-LD (trailing commas and unescaped quotes are the usual causes).",
        targetSelector: null,
        isPageLevel: true
      });
    }
    if (jsonLdBlocks.length === 0 && microdataItems === 0) {
      issues.push({
        id: "schema_missing",
        category: "Schema",
        severity: "info",
        title: "No Structured Data Found",
        message: "No JSON-LD and no microdata. Rich results (Article, FAQ, Breadcrumb, Product) are unavailable to this page.",
        recommendation: "Add JSON-LD matching the page type; Organization at the root and Article/BreadcrumbList on content.",
        targetSelector: null,
        isPageLevel: true
      });
    } else if (invalidJsonLd === 0 && jsonLdTypes.length === 0 && microdataItems === 0) {
      // Only when the block parsed. An INVALID block already produced its own
      // finding above; reporting "has no @type" for a block that could not be
      // parsed at all describes a different problem and suggests the wrong fix.
      issues.push({
        id: "schema_low_value",
        category: "Schema",
        severity: "info",
        title: "Structured Data Without A Type",
        message: "A JSON-LD block exists but declares no @type, so no rich result can be generated from it.",
        recommendation: "Give every JSON-LD object a schema.org @type such as Article or Organization.",
        targetSelector: null,
        isPageLevel: true
      });
    }

    // M. Technical and mobile -----------------------------------------
    const viewportMeta = metaContent('meta[name="viewport" i]');
    if (!viewportMeta) {
      issues.push({
        id: "viewport_missing",
        category: "Technical",
        severity: "warning",
        title: "No Viewport Meta Tag",
        message: "Without a viewport declaration mobile browsers render the desktop layout scaled down.",
        recommendation: 'Add <meta name="viewport" content="width=device-width, initial-scale=1">.',
        targetSelector: null,
        isPageLevel: true
      });
    }

    const htmlLang = (document.documentElement.getAttribute("lang") || "").trim();
    if (!htmlLang) {
      issues.push({
        id: "lang_missing",
        category: "Technical",
        severity: "warning",
        title: "Missing Page Language",
        message: "<html> has no lang attribute, so screen readers and translation tools must guess the language.",
        recommendation: 'Declare it, e.g. <html lang="en">.',
        targetSelector: null,
        isPageLevel: true
      });
    }

    const charsetMeta = document.querySelector('meta[charset]');
    const charset = charsetMeta ? (charsetMeta.getAttribute("charset") || "").trim() : "";

    const isHttps = location.protocol === "https:";
    const mixedContent = isHttps
      ? Array.from(document.querySelectorAll("img[src], script[src], link[href], iframe[src]")).filter((el) => {
          const value = el.getAttribute("src") || el.getAttribute("href") || "";
          return /^http:\/\//i.test(value);
        })
      : [];
    if (mixedContent.length > 0) {
      issues.push({
        id: "mixed_content",
        category: "Technical",
        severity: "warning",
        title: `Mixed Content (${mixedContent.length} resource${mixedContent.length === 1 ? "" : "s"})`,
        message: "This HTTPS page loads resources over plain HTTP. Browsers block or downgrade them, and they can break layout.",
        recommendation: "Serve every subresource over HTTPS (or protocol-relative URLs).",
        targetSelector: null,
        isPageLevel: true
      });
    }

    // Hreflang: a set that never references itself is the most common mistake.
    const hreflangNodes = Array.from(document.querySelectorAll('link[rel="alternate"][hreflang]'));
    const hreflangCodes = hreflangNodes.map((node) => (node.getAttribute("hreflang") || "").toLowerCase());
    if (hreflangNodes.length > 0 && !hreflangCodes.includes("x-default")) {
      issues.push({
        id: "hreflang_no_xdefault",
        category: "Technical",
        severity: "info",
        title: "Hreflang Set Has No x-default",
        message: `${hreflangNodes.length} hreflang alternates are declared but none targets x-default, so unmatched locales have no fallback.`,
        recommendation: 'Add <link rel="alternate" hreflang="x-default" href="..."> for the global fallback.',
        targetSelector: null,
        isPageLevel: true
      });
    }

    // N. Link profile --------------------------------------------------
    const hrefLinks = Array.from(document.querySelectorAll("a[href]"));
    let internalLinks = 0;
    let externalLinks = 0;
    let nofollowLinks = 0;
    let sponsoredLinks = 0;
    let ugcLinks = 0;
    let newTabMissingNoopener = 0;
    hrefLinks.forEach((a) => {
      const href = (a.getAttribute("href") || "").trim();
      if (!href || href === "#" || href.startsWith("javascript:") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
      try {
        const url = new URL(href, location.href);
        if (url.hostname === location.hostname) internalLinks += 1;
        else externalLinks += 1;
      } catch (err) {
        internalLinks += 1;
      }
      const rel = (a.getAttribute("rel") || "").toLowerCase();
      if (rel.includes("nofollow")) nofollowLinks += 1;
      if (rel.includes("sponsored")) sponsoredLinks += 1;
      if (rel.includes("ugc")) ugcLinks += 1;
      if ((a.getAttribute("target") || "").toLowerCase() === "_blank") {
        if (!rel.includes("noopener") && !rel.includes("noreferrer")) newTabMissingNoopener += 1;
      }
    });
    if (newTabMissingNoopener > 0) {
      issues.push({
        id: "target_blank_noopener",
        category: "Links",
        severity: "warning",
        title: `${newTabMissingNoopener} Blank-Target Link${newTabMissingNoopener === 1 ? "" : "s"} Without rel=noopener`,
        message: "target=\"_blank\" without rel=noopener gives the opened page a handle on window.opener (reverse tabnabbing).",
        recommendation: 'Add rel="noopener" (or "noreferrer") to every target="_blank" link.',
        targetSelector: null,
        isPageLevel: true
      });
    }

    // O. Image detail --------------------------------------------------
    const allImages = Array.from(document.querySelectorAll("img"));
    let imagesMissingDimensions = 0;
    let lazyImages = 0;
    allImages.forEach((img) => {
      if (!img.getAttribute("width") || !img.getAttribute("height")) imagesMissingDimensions += 1;
      if ((img.getAttribute("loading") || "").toLowerCase() === "lazy") lazyImages += 1;
    });
    if (imagesMissingDimensions > 0) {
      issues.push({
        id: "img_no_dimensions",
        category: "Images",
        severity: "info",
        title: `${imagesMissingDimensions} Image${imagesMissingDimensions === 1 ? "" : "s"} Without Width/Height`,
        message: "Images without explicit dimensions shift the layout as they load (Cumulative Layout Shift), which Core Web Vitals penalises.",
        recommendation: "Set width and height attributes, or reserve space with aspect-ratio in CSS.",
        targetSelector: null,
        isPageLevel: true
      });
    }

    const faviconHref = (document.querySelector('link[rel~="icon"]') || {}).href || "";
    const pageFacts = {
      meta: {
        title,
        titleLength: titleLen,
        description: metaDesc,
        descriptionLength: descLen,
        robots: robotsMeta || "(none)",
        noindex: isNoindex,
        canonical,
        canonicalSelf,
        lang: htmlLang,
        viewport: viewportMeta,
        charset,
        favicon: faviconHref,
        metaRefresh: refreshMeta ? (refreshMeta.getAttribute("content") || "").trim() : ""
      },
      social: {
        ogTitle,
        ogDescription,
        ogImage,
        ogType,
        ogUrl,
        twitterCard,
        twitterTitle,
        twitterDescription,
        twitterImage,
        missing: missingSocial
      },
      headings: { counts: headingCounts, outline: headingOutline },
      links: {
        total: hrefLinks.length,
        internal: internalLinks,
        external: externalLinks,
        nofollow: nofollowLinks,
        sponsored: sponsoredLinks,
        ugc: ugcLinks,
        emptyAnchor: emptyLinkCount,
        newTabMissingNoopener
      },
      images: {
        total: allImages.length,
        missingAlt: missingAltCount,
        missingDimensions: imagesMissingDimensions,
        lazy: lazyImages
      },
      schema: {
        blocks: jsonLdBlocks.length,
        types: Array.from(new Set(jsonLdTypes)),
        invalidBlocks: invalidJsonLd,
        microdataItems,
        items: schemaItems
      },
      hreflang: { count: hreflangNodes.length, codes: hreflangCodes },
      vitals: getPageVitals(),
      tech: {
        https: isHttps,
        mixedContent: mixedContent.length,
        wordCount,
        readingTimeMinutes: Math.max(1, Math.round(wordCount / 200)),
        domNodes: document.getElementsByTagName("*").length,
        scripts: document.scripts.length,
        stylesheets: document.styleSheets.length
      }
    };

    // Ensure score bounded [0, 100]
    score = Math.max(0, Math.min(100, Math.round(score)));

    // ---- Severity-weighted scoring (replaces ad-hoc flat deductions) -----
    //
    // The previous scheme subtracted a hand-tuned constant PER CHECK, which
    // meant the number of occurrences barely mattered. Measured on fixtures
    // built from this file's own rules:
    //   - 3 duplicate <h1> elements cost 8 points total (one flat -8), so a
    //     page with 12 missing-alt images scored 80 while a page with 3 H1s
    //     scored 92 -- the *worse* page scored higher.
    //   - A page missing title, description, canonical, H1 AND thin content
    //     landed at 29, but stacking more defects could not push it below the
    //     sum of those constants, so severity ordering was arbitrary.
    //
    // Weighting per emitted issue instead makes the score a function of how
    // many real defects exist and how serious each one is, which is what a
    // "Live SEO Score" is supposed to mean.
    //
    // `info` is weight 0. The advisory checks added with the page-facts layer
    // (social preview completeness, missing structured data, image dimensions,
    // heading skips) are recommendations, not defects: a page cannot be
    // unhealthy for lacking a Twitter card, and carrying ten of those findings
    // used to move the score more than one genuine critical.
    const SEVERITY_WEIGHT = { critical: 9, warning: 3, info: 0 };
    let weighted = 0;
    for (const issue of issues) {
      weighted += SEVERITY_WEIGHT[issue.severity] ?? 1;
    }
    // Each weighted point costs 1.6 score points. The multiplier is set from
    // measurement, not taste: a page missing its title, description, canonical
    // and H1 *and* carrying thin content (4 critical + 1 warning = 39 weighted)
    // must land below 40, because that page is not meaningfully usable for
    // search. At 1.15 it scored 55; at 1.6 it scores 38. A single warning still
    // costs only ~5 points, so minor findings stay minor.
    score = Math.max(0, Math.min(100, Math.round(100 - weighted * 1.6)));

    // Return structured report
    cachedAuditData = {
      url: window.location.href,
      domain: window.location.hostname,
      // Top-level `title` is what the side panel and the drawer both read.
      // It was never populated (only stats.title existed), so every page
      // rendered as "Untitled Webpage" and the drawer silently dropped its
      // page-title line. Keep both: stats.title feeds the facts grid.
      title,
      score,
      stats: {
        title,
        titleLength: titleLen,
        metaDescription: metaDesc,
        metaDescLength: descLen,
        canonical,
        h1: h1s.length ? (h1s[0].textContent || "").trim() : "",
        h1Count: h1s.length,
        h2Count: h2s.length,
        h3Count: h3s.length,
        totalImages: images.length,
        missingAltCount,
        totalLinks: links.length,
        emptyLinkCount,
        wordCount,
        readingTimeMinutes: Math.max(1, Math.round(wordCount / 200)),
        internalLinks: internalLinks,
        externalLinks: externalLinks,
        nofollowLinks: nofollowLinks,
        schemaTypes: pageFacts.schema.types,
        robots: robotsMeta || "(none)",
        lang: htmlLang,
        noindex: isNoindex
      },
      facts: pageFacts,
      issues: issues.map(({ domElement, ...rest }) => rest) // strip non-serializable elements for messaging
    };

    updateFloatingPill(cachedAuditData);
    return cachedAuditData;
  }

  // -------------------------------------------------------------
  // 2. PRECISION DOM PATH GENERATOR
  // -------------------------------------------------------------
  function escapeSelectorIdent(value) {
    if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
      return CSS.escape(value);
    }
    return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function getElementPath(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return "";
    if (el.id) return `#${escapeSelectorIdent(el.id)}`;
    if (el.tagName.toLowerCase() === "body") return "body";

    let path = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && current.tagName.toLowerCase() !== "body") {
      let selector = current.tagName.toLowerCase();
      if (current.className && typeof current.className === "string") {
        const classes = current.className
          .trim()
          .split(/\s+/)
          .filter(c => c && !c.startsWith("rankace-") && c.length < 30);
        if (classes.length > 0) {
          selector += `.${escapeSelectorIdent(classes[0])}`;
        }
      }
      let parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
        if (siblings.length > 1) {
          const index = siblings.indexOf(current) + 1;
          selector += `:nth-of-type(${index})`;
        }
      }
      path.unshift(selector);
      current = parent;
    }
    return path.join(" > ");
  }

  // -------------------------------------------------------------
  // 3. VISUAL BOUNDING BOX HIGHLIGHTER ENGINE
  // -------------------------------------------------------------
  function clearAllHighlights() {
    activeHighlightBoxes.forEach(box => {
      if (box && box.parentNode) box.parentNode.removeChild(box);
    });
    activeHighlightBoxes = [];
    allHighlighted = false;
  }

  function highlightSingleElement(targetSelector, issue) {
    clearAllHighlights();
    let el = null;
    if (targetSelector) {
      try {
        el = document.querySelector(targetSelector);
      } catch (e) {
        el = null;
      }
    }
    if (!el) {
      console.warn("Rankace: Target element not found for selector:", targetSelector);
      return false;
    }

    // Smooth scroll into center view
    el.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });

    // Build the visual bounding box
    setTimeout(() => {
      createBoundingBox(el, issue);
    }, 250);

    return true;
  }

  function createBoundingBox(el, issue) {
    if (!el || !el.isConnected) return null;
    const tag = el.tagName ? el.tagName.toLowerCase() : "";
    if (tag === "body" || tag === "html" || tag === "head") return null;

    const rect = el.getBoundingClientRect();
    // Strictly ignore 0x0 or invisible elements
    if (rect.width < 16 || rect.height < 16) return null;

    const box = document.createElement("div");
    const severityClass = issue.severity === "critical" ? "rankace-critical" : issue.severity === "warning" ? "rankace-warning" : "rankace-info";
    box.className = `rankace-defect-box ${severityClass}`;
    if (rect.height < 45) box.classList.add("rankace-short");
    box._targetElement = el;
    box._issueData = issue;
    
    // Position fixed coordinates directly relative to viewport
    box.style.top = `${rect.top - 4}px`;
    box.style.left = `${rect.left - 4}px`;
    box.style.width = `${Math.max(rect.width + 8, 24)}px`;
    box.style.height = `${Math.max(rect.height + 8, 20)}px`;

    // Docked Badge INSIDE the bounding box - never overlaps outside headings!
    const badge = document.createElement("div");
    badge.className = "rankace-defect-badge";
    badge.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleInPageDrawer(true);
    });

    const badgePill = document.createElement("span");
    badgePill.className = `rankace-badge-pill rankace-badge-${issue.severity}`;
    badgePill.textContent = issue.severity.toUpperCase();

    const titleSpan = document.createElement("span");
    // Short readable label
    let shortLabel = issue.title;
    if (shortLabel.includes("alt") || shortLabel.includes("Alt")) shortLabel = "No Alt Text";
    else if (shortLabel.includes("Multiple <h1>")) shortLabel = "Duplicate H1";
    else if (shortLabel.includes("Empty <h1>")) shortLabel = "Empty H1";
    else if (shortLabel.includes("Empty Link")) shortLabel = "Empty Link";
    else if (shortLabel.includes("Generic Anchor")) shortLabel = "Generic Link";
    titleSpan.textContent = shortLabel;

    const closeBtn = document.createElement("button");
    closeBtn.className = "rankace-badge-close";
    closeBtn.innerHTML = "&times;";
    closeBtn.title = "Dismiss highlight";
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      box.remove();
      const idx = activeHighlightBoxes.indexOf(box);
      if (idx > -1) activeHighlightBoxes.splice(idx, 1);
    });

    // Hover Tooltip that opens below the badge
    const tooltip = document.createElement("div");
    tooltip.className = "rankace-defect-tooltip";
    tooltip.innerHTML = `
      <strong>${escapeHTML(issue.title)}</strong>
      <div>${escapeHTML(issue.message)}</div>
      <div class="rankace-tooltip-fix">💡 ${escapeHTML(issue.recommendation)}</div>
    `;

    badge.appendChild(badgePill);
    badge.appendChild(titleSpan);
    badge.appendChild(closeBtn);
    badge.appendChild(tooltip);

    box.appendChild(badge);

    document.body.appendChild(box);
    activeHighlightBoxes.push(box);
    return box;
  }

  function repositionAllBoxes() {
    if (!isInspectionEnabled || activeHighlightBoxes.length === 0) return;
    const vh = window.innerHeight;
    const vw = window.innerWidth;

    for (let i = activeHighlightBoxes.length - 1; i >= 0; i--) {
      const box = activeHighlightBoxes[i];
      const el = box._targetElement;
      if (!el || !document.contains(el)) {
        box.remove();
        activeHighlightBoxes.splice(i, 1);
        continue;
      }

      const rect = el.getBoundingClientRect();
      // If off screen or 0 dimensions, hide
      if (rect.bottom < -40 || rect.top > vh + 40 || rect.right < -40 || rect.left > vw + 40 || rect.width < 10 || rect.height < 10) {
        box.style.display = "none";
      } else {
        box.style.display = "block";
        box.style.top = `${rect.top - 4}px`;
        box.style.left = `${rect.left - 4}px`;
        box.style.width = `${Math.max(rect.width + 8, 24)}px`;
        box.style.height = `${Math.max(rect.height + 8, 20)}px`;

        if (rect.height < 45) {
          box.classList.add("rankace-short");
        } else {
          box.classList.remove("rankace-short");
        }
      }
    }
  }

  function highlightAllIssuesOnPage(issues) {
    clearAllHighlights();
    if (!isInspectionEnabled) return 0;
    allHighlighted = true;
    let count = 0;

    issues.forEach(issue => {
      // Never draw bounding boxes for page-level issues or root tags
      if (issue.isPageLevel || (!issue.domElement && (!issue.targetSelector || issue.targetSelector === "head" || issue.targetSelector === "body"))) return;
      
      let el = issue.domElement;
      if (!el || !el.isConnected) {
        if (issue.targetSelector && issue.targetSelector !== "head" && issue.targetSelector !== "body") {
          try {
            el = document.querySelector(issue.targetSelector);
          } catch (e) {
            el = null;
          }
        }
      }

      if (el && el.isConnected) {
        const rect = el.getBoundingClientRect();
        const style = window.getComputedStyle(el);
        if (rect.width >= 16 && rect.height >= 16 && style.display !== "none" && style.visibility !== "hidden") {
          const box = createBoundingBox(el, issue);
          if (box) count++;
        }
      }
    });

    return count;
  }

  // -------------------------------------------------------------
  // 4. FLOATING TRIGGER PILL & IN-PAGE DRAWER (COMET-STYLE)
  // -------------------------------------------------------------
  let drawerOpen = false;

  function updateFloatingPill(audit) {
    let pill = document.getElementById("rankace-floating-pill");
    if (!pill) {
      pill = document.createElement("div");
      pill.id = "rankace-floating-pill";
      pill.title = "Click to open Rankace Assistant & highlight defects (Alt+R)";
      pill.addEventListener("click", () => {
        toggleInPageDrawer();
      });
      document.body.appendChild(pill);
    }

    // Count EVERY issue, not just critical+warning. The old line was
    // `criticalCount + warningCount`, so a page whose only findings were
    // info-severity (non-descriptive anchor text) displayed "Clean" while the
    // drawer listed real problems -- the pill and the panel contradicted each
    // other on the same page.
    const criticalCount = audit.issues.filter(i => i.severity === "critical").length;
    const warningCount = audit.issues.filter(i => i.severity === "warning").length;
    const infoCount = audit.issues.filter(i => i.severity === "info").length;
    const totalIssues = audit.issues.length;

    pill.innerHTML = `
      <span class="rankace-icon">⚡</span>
      <span>Rankace</span>
      <span class="rankace-score">${audit.score}</span>
      ${totalIssues > 0 ? `<span class="rankace-counter">${totalIssues} Fixes</span>` : `<span class="rankace-counter rankace-is-clean">Clean</span>`}
    `;
  }

  function toggleInPageDrawer(forceOpen) {
    let drawer = document.getElementById("rankace-inpage-drawer");
    if (!drawer) {
      drawer = createInPageDrawer();
      document.body.appendChild(drawer);
    }

    if (forceOpen === true) {
      drawerOpen = true;
    } else if (forceOpen === false) {
      drawerOpen = false;
    } else {
      drawerOpen = !drawerOpen;
    }

    if (drawerOpen) {
      drawer.classList.add("rankace-open");
      const audit = runLiveAudit();
      renderDrawerContent(audit);
      // Auto-box defects on page for instant 1-click feedback
      highlightAllIssuesOnPage(audit.issues);
    } else {
      drawer.classList.remove("rankace-open");
      clearAllHighlights();
    }
  }

  function createInPageDrawer() {
    const drawer = document.createElement("div");
    drawer.id = "rankace-inpage-drawer";

    drawer.innerHTML = `
      <div class="rankace-drawer-header">
        <div class="rankace-drawer-brand">
          <div class="rankace-drawer-brand-logo">⚡</div>
          <div>
            <div class="rankace-drawer-title">RANKACE</div>
            <div class="rankace-drawer-subtitle">Live Page Inspector</div>
          </div>
        </div>
        <div class="rankace-drawer-actions">
          <button id="rankace-drawer-autofix" class="rankace-drawer-btn rankace-autofix-btn" title="Apply all safe corrections to this page">✨ Auto-Fix</button>
          <button id="rankace-drawer-rescan" class="rankace-drawer-btn" title="Re-scan DOM">🔄 Re-Scan</button>
          <button id="rankace-drawer-close" class="rankace-drawer-close" title="Close Assistant (Esc)">&times;</button>
        </div>
      </div>
      <div id="rankace-drawer-body" class="rankace-drawer-body">
        <!-- Content dynamically rendered -->
      </div>
    `;

    drawer.querySelector("#rankace-drawer-close").addEventListener("click", () => {
      toggleInPageDrawer(false);
    });

    drawer.querySelector("#rankace-drawer-rescan").addEventListener("click", () => {
      const audit = runLiveAudit();
      renderDrawerContent(audit);
      highlightAllIssuesOnPage(audit.issues);
    });

    drawer.querySelector("#rankace-drawer-autofix").addEventListener("click", () => {
      const result = applyAllFixes();
      renderDrawerContent(runLiveAudit(), result);
      highlightAllIssuesOnPage(cachedAuditData ? cachedAuditData.issues : []);
    });

    return drawer;
  }

  function renderDrawerContent(audit, fixResult) {
    const body = document.getElementById("rankace-drawer-body");
    if (!body) return;
    if (fixResult === undefined) fixResult = lastFixResult;

    const critCount = audit.issues.filter(i => i.severity === "critical").length;
    const warnCount = audit.issues.filter(i => i.severity === "warning").length;
    const infoCount = audit.issues.filter(i => i.severity === "info").length;

    let scoreStatus = audit.score >= 85 ? "Excellent Condition" : audit.score >= 65 ? "Needs Optimization" : "Critical Fixes Required";
    let scoreClass = audit.score >= 85 ? "rankace-ok" : audit.score >= 65 ? "rankace-warn" : "rankace-bad";
    let scoreHex = audit.score >= 85 ? "#2fbf71" : audit.score >= 65 ? "#d9a441" : "#e5484d";

    body.innerHTML = `
      <!-- Master Switch Bar: ON / OFF -->
      <div id="rankace-drawer-power-card" class="rankace-power-card">
        <div>
          <div class="rankace-power-state${isInspectionEnabled ? " rankace-is-on" : ""}">
            <span class="rankace-dot"></span>
            <span id="rankace-drawer-power-label">${isInspectionEnabled ? "INSPECTOR ON" : "INSPECTION PAUSED"}</span>
          </div>
          <div id="rankace-drawer-power-sub" class="rankace-power-sub">
            ${isInspectionEnabled ? "Bounding boxes active on page defects" : "All bounding boxes cleared • Webpage clean"}
          </div>
        </div>
        <button id="rankace-drawer-power-btn" class="rankace-power-btn${isInspectionEnabled ? "" : " rankace-is-off"}">
          <span aria-hidden="true">⏻</span>
          <span id="rankace-drawer-power-btn-text">${isInspectionEnabled ? "SWITCH OFF" : "SWITCH ON"}</span>
        </button>
      </div>

      <!-- Audited Website Link Card -->
      <div class="rankace-card">
        <div class="rankace-card-row">
          <span class="rankace-eyebrow">AUDITED WEBPAGE</span>
          <span class="rankace-timestamp">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
        </div>
        <div class="rankace-urlbar">
          <span aria-hidden="true">🌐</span>
          <a href="${escapeAttr(audit.url)}" target="_blank" rel="noopener noreferrer" class="rankace-url-link" title="Open audited webpage in new tab">
            ${escapeHTML(audit.url)}
          </a>
          <button id="rankace-drawer-copy-url" class="rankace-copy-btn" title="Copy webpage link">
            📋 Copy
          </button>
        </div>
        ${audit.title ? `<div class="rankace-page-title">Page: "${escapeHTML(audit.title)}"</div>` : ""}
      </div>

      <!-- Score Hero -->
      <div class="rankace-score-hero">
        <div class="rankace-score-ring" style="background:conic-gradient(${scoreHex} ${(audit.score/100)*360}deg, rgba(255,255,255,0.11) 0deg);">
          <div class="rankace-score-ring-inner"></div>
          <span class="rankace-score-value">${audit.score}</span>
        </div>
        <div style="flex:1 1 auto; min-width:0;">
          <div class="rankace-score-label">Live SEO Score</div>
          <div class="rankace-score-status ${scoreClass}">${scoreStatus}</div>
          <div class="rankace-counts">
            <span class="rankace-count rankace-count-critical">${critCount} Critical</span>
            <span class="rankace-count rankace-count-warning">${warnCount} Warnings</span>
            ${infoCount > 0 ? `<span class="rankace-count rankace-count-info">${infoCount} Info</span>` : ""}
          </div>
        </div>
      </div>

      <!-- Page Facts + SERP preview (mirrors the side panel's detail view) -->
      <div class="rankace-card">
        <div class="rankace-card-row">
          <span class="rankace-eyebrow">PAGE FACTS</span>
          <span class="rankace-timestamp">${audit.stats.wordCount.toLocaleString()} words</span>
        </div>
        <div class="rankace-serp">
          <div class="rankace-serp-url">${escapeHTML(audit.url)}</div>
          <div class="rankace-serp-title">${escapeHTML(audit.title || "(no title tag)")}</div>
          <div class="rankace-serp-desc">${escapeHTML(audit.stats.metaDescription || "(no meta description — search engines will invent a snippet)")}</div>
        </div>
        <div class="rankace-facts-grid">
          ${[
            ["Robots", audit.facts && audit.facts.meta ? audit.facts.meta.robots : "—"],
            ["Canonical", audit.stats.canonical ? (audit.facts && audit.facts.meta && audit.facts.meta.canonicalSelf === false ? "cross-domain" : "self") : "missing"],
            ["Language", (audit.facts && audit.facts.meta && audit.facts.meta.lang) || "missing"],
            ["Schema", audit.facts && audit.facts.schema.types.length ? audit.facts.schema.types.slice(0, 3).join(", ") : "none"],
            ["Links in / out", `${audit.stats.internalLinks || 0} / ${audit.stats.externalLinks || 0}`],
            ["Nofollow", String(audit.stats.nofollowLinks || 0)]
          ].map(([label, value]) => `
            <div class="rankace-fact">
              <span class="rankace-fact-label">${escapeHTML(label)}</span>
              <span class="rankace-fact-value">${escapeHTML(String(value))}</span>
            </div>
          `).join("")}
        </div>
        <button id="rankace-drawer-copy-report" class="rankace-copy-btn" style="margin-top:10px;width:100%;justify-content:center;">
          📋 Copy Full Report
        </button>
      </div>

      <!-- Auto-Fix card -->
      <div class="rankace-card rankace-autofix-card">
        <div class="rankace-card-row">
          <span class="rankace-eyebrow">AUTO-FIX</span>
          <span class="rankace-timestamp">${fixResult ? `${fixResult.scoreBefore} → ${fixResult.scoreAfter}` : "local only"}</span>
        </div>
        ${fixResult ? `
          <div class="rankace-autofix-summary">
            ${fixResult.applied.length > 0 ? `<div class="rankace-autofix-line rankace-ok">✓ ${fixResult.applied.length} correction${fixResult.applied.length === 1 ? "" : "s"} applied to this page</div>` : ""}
            ${fixResult.skipped.length > 0 ? `<div class="rankace-autofix-line rankace-warn">⚠ ${fixResult.skipped.length} could not be derived automatically</div>` : ""}
            ${fixResult.manual.length > 0 ? `<div class="rankace-autofix-line rankace-warn">✎ ${fixResult.manual.length} need a human decision</div>` : ""}
          </div>
          <div class="rankace-autofix-list">
            ${fixResult.applied.map(f => `
              <div class="rankace-autofix-item">
                <span class="rankace-autofix-check">✓</span>
                <div>
                  <div class="rankace-autofix-title">${escapeHTML(f.title)}</div>
                  ${f.detail ? `<div class="rankace-autofix-detail">${escapeHTML(f.detail)}</div>` : ""}
                </div>
              </div>
            `).join("")}
            ${fixResult.manual.map(f => `
              <div class="rankace-autofix-item">
                <span class="rankace-autofix-check rankace-manual">✎</span>
                <div>
                  <div class="rankace-autofix-title">${escapeHTML(f.title)}</div>
                  ${f.detail ? `<div class="rankace-autofix-detail">${escapeHTML(f.detail)}</div>` : ""}
                </div>
              </div>
            `).join("")}
          </div>
          <div class="rankace-autofix-note">
            Fixes live only in this tab — reload discards them. Download the corrected file to keep them.
          </div>
          <div class="rankace-autofix-actions">
            <button id="rankace-drawer-download-html" class="rankace-copy-btn rankace-autofix-primary">⬇ Download corrected .html</button>
            <button id="rankace-drawer-fix-again" class="rankace-copy-btn">🔄 Re-run</button>
          </div>
        ` : `
          <div class="rankace-autofix-desc">
            Correct every issue the extension can fix safely — title, description, canonical, lang, viewport, charset, noindex, duplicate H1s, image alt text and link rel — then export the corrected page as an .html file.
          </div>
          <div class="rankace-autofix-actions">
            <button id="rankace-drawer-run-fixes" class="rankace-copy-btn rankace-autofix-primary">✨ Fix all fixable issues</button>
            <button id="rankace-drawer-download-html" class="rankace-copy-btn">⬇ Corrected file</button>
          </div>
        `}
      </div>

      <!-- Master Box Toggle Switch -->
      <div class="rankace-toggle-row">
        <div>
          <div class="rankace-power-label">🎯 Box Defects on Page</div>
          <div class="rankace-power-sub">Draw glowing boxes over problematic elements</div>
        </div>
        <label class="toggle">
          <input type="checkbox" id="rankace-drawer-toggle-boxes" ${isInspectionEnabled ? 'checked' : ''}>
          <span class="slider"></span>
        </label>
      </div>

      <!-- Issues Feed Header -->
      <div class="rankace-feed-head">
        Issues Found (${audit.issues.length})
      </div>

      <!-- Issues List -->
      <div id="rankace-drawer-issues-list" class="rankace-drawer-issues-list">
        ${audit.issues.map(issue => `
          <div class="rankace-issue-card ${issue.severity}">
            <div class="rankace-issue-top">
              <div class="rankace-issue-title">${escapeHTML(issue.title)}</div>
              <span class="rankace-badge-tag ${issue.severity}">${issue.severity.toUpperCase()}</span>
            </div>
            <div class="rankace-issue-msg">${escapeHTML(issue.message)}</div>
            <div class="rankace-issue-fix">💡 ${escapeHTML(issue.recommendation)}</div>
            <div class="rankace-issue-foot">
              ${issue.targetSelector && issue.targetSelector !== 'head' ? `
                <button class="rankace-drawer-inspect-btn" data-selector="${escapeAttr(issue.targetSelector)}">
                  👁 Inspect on page
                </button>
              ` : `<span class="rankace-issue-foot-note">Page-level &lt;head&gt; tag</span>`}
            </div>
          </div>
        `).join("")}
      </div>
    `;

    // Power button handler in drawer
    const drawerPowerBtn = body.querySelector("#rankace-drawer-power-btn");
    if (drawerPowerBtn) {
      drawerPowerBtn.addEventListener("click", () => {
        isInspectionEnabled = !isInspectionEnabled;
        if (isInspectionEnabled) {
          highlightAllIssuesOnPage(audit.issues);
        } else {
          clearAllHighlights();
        }
        renderDrawerContent(audit);
      });
    }

    // Copy the whole audit as text, so a finding can leave the browser.
    const drawerCopyReport = body.querySelector("#rankace-drawer-copy-report");
    if (drawerCopyReport && navigator.clipboard) {
      drawerCopyReport.addEventListener("click", () => {
        const text = buildTextReport(audit);
        navigator.clipboard.writeText(text).then(() => {
          const prev = drawerCopyReport.innerHTML;
          drawerCopyReport.innerHTML = "✓ Report copied";
          setTimeout(() => { drawerCopyReport.innerHTML = prev; }, 1800);
        }).catch(() => {});
      });
    }

    // Copy URL button in drawer
    const drawerCopyBtn = body.querySelector("#rankace-drawer-copy-url");
    if (drawerCopyBtn && navigator.clipboard) {
      drawerCopyBtn.addEventListener("click", () => {
        navigator.clipboard.writeText(audit.url).then(() => {
          const prev = drawerCopyBtn.innerHTML;
          drawerCopyBtn.innerHTML = "✓ Copied!";
          drawerCopyBtn.classList.add("rankace-is-done");
          setTimeout(() => {
            drawerCopyBtn.innerHTML = prev;
            drawerCopyBtn.classList.remove("rankace-is-done");
          }, 1800);
        }).catch(() => {});
      });
    }

    // Auto-Fix card buttons
    const runFixesBtn = body.querySelector("#rankace-drawer-run-fixes");
    if (runFixesBtn) {
      runFixesBtn.addEventListener("click", () => {
        const result = applyAllFixes();
        renderDrawerContent(runLiveAudit(), result);
        highlightAllIssuesOnPage(cachedAuditData ? cachedAuditData.issues : []);
      });
    }
    const fixAgainBtn = body.querySelector("#rankace-drawer-fix-again");
    if (fixAgainBtn) {
      fixAgainBtn.addEventListener("click", () => {
        const result = applyAllFixes();
        renderDrawerContent(runLiveAudit(), result);
        highlightAllIssuesOnPage(cachedAuditData ? cachedAuditData.issues : []);
      });
    }
    const downloadHtmlBtns = body.querySelectorAll("#rankace-drawer-download-html");
    downloadHtmlBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        const res = downloadCorrectedHtml();
        const prev = btn.innerHTML;
        btn.innerHTML = res.ok ? `✓ Saved ${res.filename}` : `⚠ ${res.note}`;
        btn.classList.add("rankace-is-done");
        setTimeout(() => { btn.innerHTML = prev; btn.classList.remove("rankace-is-done"); }, 2600);
      });
    });

    // Toggle bounding boxes listener
    const toggleBoxes = body.querySelector("#rankace-drawer-toggle-boxes");
    if (toggleBoxes) {
      toggleBoxes.addEventListener("change", (e) => {
        isInspectionEnabled = e.target.checked;
        if (isInspectionEnabled) {
          highlightAllIssuesOnPage(audit.issues);
        } else {
          clearAllHighlights();
        }
        renderDrawerContent(audit);
      });
    }

    // Inspect buttons
    body.querySelectorAll(".rankace-drawer-inspect-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const selector = btn.getAttribute("data-selector");
        const issue = audit.issues.find(i => i.targetSelector === selector);
        if (issue) {
          highlightSingleElement(selector, issue);
        }
      });
    });
  }

  function buildTextReport(audit) {
    const lines = [
      `Rankace page report — ${audit.url}`,
      `Scanned: ${new Date().toISOString()}`,
      `On-page score: ${audit.score}/100`,
      "",
      `Title (${audit.stats.titleLength}): ${audit.stats.title || "(missing)"}`,
      `Description (${audit.stats.metaDescLength}): ${audit.stats.metaDescription || "(missing)"}`,
      `Canonical: ${audit.stats.canonical || "(missing)"}`,
      `Robots: ${audit.stats.robots || "(none)"}`,
      `Language: ${audit.stats.lang || "(missing)"}`,
      `Words: ${audit.stats.wordCount} · H1: ${audit.stats.h1Count} · H2: ${audit.stats.h2Count} · H3: ${audit.stats.h3Count}`,
      `Links: ${audit.stats.internalLinks} internal / ${audit.stats.externalLinks} external / ${audit.stats.nofollowLinks} nofollow`,
      `Schema: ${(audit.stats.schemaTypes || []).join(", ") || "none"}`,
      "",
      `Findings (${audit.issues.length}):`
    ];
    audit.issues.forEach((issue) => {
      lines.push(`- [${issue.severity.toUpperCase()}] ${issue.title}`);
      lines.push(`  ${issue.message}`);
      lines.push(`  Fix: ${issue.recommendation}`);
      if (issue.targetSelector) lines.push(`  Element: ${issue.targetSelector}`);
    });
    return lines.join("\n");
  }

  function escapeHTML(str) {
    return (str || "").replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  function escapeAttr(str) {
    return (str || "").replace(/"/g, '&quot;');
  }

  // -------------------------------------------------------------
  // 4b. AUTO-FIX ENGINE
  //
  // Two products, both derived from the same audit:
  //   1. LIVE PATCH  -- applies safe DOM mutations so the user sees the
  //      corrected page immediately (head tags, alt text, rel/target).
  //      Patches are reversible in-session and purely local: no data leaves
  //      the browser, and reloading the page discards them.
  //   2. CORRECTED FILE -- a serialization of the ORIGINAL html with the
  //      same head-level fixes folded in, downloadable as .html so it can
  //      be uploaded to the real server. The body is never rewritten,
  //      because the page's framework owns it.
  //
  // Every fix is derived from facts already collected by runLiveAudit(),
  // and NEVER from page-supplied strings (og:description, JSON-LD, href
  // attributes): those are untrusted input and would let a page inject
  // markup into the downloaded file. Anything unresolved is listed in
  // `manual` instead of guessed at.

  const AUTO_FIX = {
    applied: [],
    skipped: [],
    manual: []
  };

  // The last auto-fix result stays sticky: the MutationObserver re-renders
  // the drawer after every page mutation (including our own fixes) and would
  // otherwise erase the results card 400ms after it appears.
  let lastFixResult = null;

  function resetAutoFix() {
    AUTO_FIX.applied = [];
    AUTO_FIX.skipped = [];
    AUTO_FIX.manual = [];
  }

  function recordAutoFix(fix) {
    AUTO_FIX.applied.push(fix);
    return fix;
  }

  function recordSkipped(id, reason) {
    AUTO_FIX.skipped.push({ id, reason });
    return null;
  }

  // -- head tag helpers (safe: only our own literals or derived values) ---
  function ensureHead() {
    let head = document.head;
    if (!head) {
      head = document.createElement("head");
      document.documentElement.insertBefore(head, document.documentElement.firstChild);
    }
    return head;
  }

  function ensureMetaByName(name) {
    const lower = name.toLowerCase();
    let el = Array.from(document.querySelectorAll("meta[name]")).find(
      (m) => (m.getAttribute("name") || "").toLowerCase() === lower
    );
    if (!el) {
      el = document.createElement("meta");
      el.setAttribute("name", name);
      ensureHead().appendChild(el);
    }
    return el;
  }

  function ensureMetaByProperty(prop) {
    const lower = prop.toLowerCase();
    let el = Array.from(document.querySelectorAll("meta[property]")).find(
      (m) => (m.getAttribute("property") || "").toLowerCase() === lower
    );
    if (!el) {
      el = document.createElement("meta");
      el.setAttribute("property", prop);
      ensureHead().appendChild(el);
    }
    return el;
  }

  function ensureCanonical() {
    let el = document.querySelector('link[rel="canonical"]');
    if (!el) {
      el = document.createElement("link");
      el.setAttribute("rel", "canonical");
      ensureHead().appendChild(el);
    }
    return el;
  }

  function addIssueIfAbsent(id, issue, issues) {
    if (!issues.some((i) => i.id === id)) issues.push(issue);
  }

  function slugify(text) {
    return (text || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "page";
  }

  function deriveAltText(img) {
    // Filename as a last resort: some real signal beats an empty string,
    // and the manual list always says a human should rewrite it.
    try {
      const src = new URL(img.getAttribute("src") || "", location.href).pathname;
      const base = (src.split("/").pop() || "").replace(/\.[a-z0-9]+$/i, "");
      return base.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
    } catch (err) {
      return "";
    }
  }

  /**
   * Apply every correction the extension can safely make to the LIVE DOM.
   * Returns { applied, skipped, manual, scoreBefore, scoreAfter }.
   */
  function applyAllFixes() {
    resetAutoFix();
    const before = runLiveAudit();

    // 1. Title tag -----------------------------------------------------
    if (!document.title || !document.title.trim()) {
      const h1 = document.querySelector("h1");
      const candidate = (h1 && h1.textContent ? h1.textContent : "").replace(/\s+/g, " ").trim();
      if (candidate) {
        document.title = candidate.slice(0, 60);
        recordAutoFix({
          id: "title_added",
          title: "Added <title> from the page H1",
          detail: `"${document.title}" (edit to your final wording)`
        });
      } else {
        recordSkipped("title_missing", "No title and no H1 to derive one from — write a title manually.");
      }
    }

    // 2. Meta description ---------------------------------------------
    const existingDesc = document.querySelector('meta[name="description" i]');
    if (!existingDesc || !(existingDesc.getAttribute("content") || "").trim()) {
      const bodyClone = document.body ? document.body.cloneNode(true) : null;
      if (bodyClone) {
        bodyClone.querySelectorAll('[id^="rankace-"], [class*="rankace-"], script, style, noscript').forEach((el) => el.remove());
      }
      const bodyText = (bodyClone ? bodyClone.textContent || "" : "").replace(/\s+/g, " ").trim();
      const headingText = (document.querySelector("h1, h2") || {}).textContent || "";
      const lead = bodyText.replace(/^\s+/, "").slice(0, 155).trim();
      const candidate = (lead || headingText.replace(/\s+/g, " ").trim()).slice(0, 155);
      if (candidate) {
        const el = ensureMetaByName("description");
        el.setAttribute("content", candidate);
        recordAutoFix({
          id: "desc_added",
          title: "Added meta description from the opening paragraph",
          detail: `"${candidate}…" (a human should polish the hook)`
        });
      } else {
        recordSkipped("desc_missing", "Page has no text to derive a description from — write one manually.");
      }
    }

    // 3. Canonical -----------------------------------------------------
    const canonicalEl = document.querySelector('link[rel="canonical"]');
    const existingCanonicalHref = canonicalEl ? (canonicalEl.getAttribute("href") || "").trim() : "";
    if (!existingCanonicalHref && location.protocol.startsWith("http")) {
      const el = ensureCanonical();
      el.setAttribute("href", location.href.split("#")[0]);
      recordAutoFix({
        id: "canonical_added",
        title: "Added self-referencing canonical",
        detail: location.href.split("#")[0]
      });
    }

    // 4. Language -------------------------------------------------------
    if (!(document.documentElement.getAttribute("lang") || "").trim()) {
      const nav = ((navigator.language || "en") + "").toLowerCase();
      document.documentElement.setAttribute("lang", nav);
      recordAutoFix({
        id: "lang_added",
        title: "Declared page language on <html>",
        detail: `lang="${nav}" (from your browser language — correct it if the page targets another locale)`
      });
    }

    // 5. Viewport -------------------------------------------------------
    if (!document.querySelector('meta[name="viewport" i]')) {
      const el = document.createElement("meta");
      el.setAttribute("name", "viewport");
      el.setAttribute("content", "width=device-width, initial-scale=1");
      ensureHead().appendChild(el);
      recordAutoFix({
        id: "viewport_added",
        title: "Added responsive viewport meta",
        detail: 'content="width=device-width, initial-scale=1"'
      });
    }

    // 6. Charset ---------------------------------------------------------
    if (!document.querySelector("meta[charset]")) {
      const el = document.createElement("meta");
      el.setAttribute("charset", "utf-8");
      ensureHead().insertBefore(el, ensureHead().firstChild);
      recordAutoFix({
        id: "charset_added",
        title: "Added <meta charset=\"utf-8\">",
        detail: "Prevents mojibake on non-ASCII text"
      });
    }

    // 7. Robots meta (only strips noindex — never invents directives) ------
    const robotsEl = document.querySelector('meta[name="robots" i]');
    if (robotsEl) {
      const content = (robotsEl.getAttribute("content") || "").trim();
      const cleaned = content
        .split(",")
        .map((d) => d.trim())
        .filter((d) => !/^(noindex|none)$/i.test(d))
        .join(", ");
      if (cleaned !== content) {
        robotsEl.setAttribute("content", cleaned);
        recordAutoFix({
          id: "noindex_removed",
          title: "Removed noindex directive",
          detail: `robots meta changed "${content}" → "${cleaned || '(empty)'}"`
        });
      }
    }

    // 8. Heading hierarchy ----------------------------------------------
    const extraH1s = Array.from(document.querySelectorAll("h1")).slice(1);
    extraH1s.forEach((el, idx) => {
      const tag = document.createElement("h2");
      while (el.firstChild) tag.appendChild(el.firstChild);
      Array.from(el.attributes).forEach((attr) => {
        if (attr.name !== "class" && attr.name !== "id") tag.setAttribute(attr.name, attr.value);
      });
      if (el.className) tag.setAttribute("class", el.className);
      el.parentNode.replaceChild(tag, el);
      recordAutoFix({
        id: `h1_demoted_${idx}`,
        title: "Demoted duplicate <h1> to <h2>",
        detail: `"${(tag.textContent || "").replace(/\s+/g, " ").trim().slice(0, 50)}"`
      });
    });

    // 9. Image alt text (visible content images only — same filter as audit)
    let altFixed = 0;
    Array.from(document.querySelectorAll("img")).forEach((img) => {
      if (!img.isConnected) return;
      const style = window.getComputedStyle(img);
      if (style.display === "none" || style.visibility === "hidden" || parseFloat(style.opacity || "1") === 0) return;
      if (img.offsetParent === null && style.position !== "fixed") return;
      const rect = img.getBoundingClientRect();
      if (rect.width < 24 || rect.height < 24) return;
      if (img.getAttribute("role") === "presentation" || img.getAttribute("role") === "none" || img.getAttribute("aria-hidden") === "true") return;
      if ((img.getAttribute("aria-label") || "").trim() || img.getAttribute("aria-labelledby")) return;
      if (img.hasAttribute("alt") && (img.getAttribute("alt") || "").trim()) return;

      const guess = deriveAltText(img);
      if (guess) {
        img.setAttribute("alt", guess);
        altFixed += 1;
      } else if (img.hasAttribute("alt")) {
        img.setAttribute("alt", "");
        altFixed += 1;
      } else {
        AUTO_FIX.manual.push({
          id: "img_alt_manual",
          title: "Image needs a written description",
          detail: getElementPath(img)
        });
      }
    });
    if (altFixed > 0) {
      recordAutoFix({
        id: "alt_added",
        title: `Filled alt text on ${altFixed} image${altFixed === 1 ? "" : "s"}`,
        detail: "Derived from filenames — rewrite the important ones in the source."
      });
    }

    // 10. Link rel/target hygiene ---------------------------------------
    let noopenerFixed = 0;
    Array.from(document.querySelectorAll('a[href]')).forEach((a) => {
      if ((a.getAttribute("target") || "").toLowerCase() !== "_blank") return;
      const rel = (a.getAttribute("rel") || "").toLowerCase();
      if (rel.includes("noopener") || rel.includes("noreferrer")) return;
      a.setAttribute("rel", (a.getAttribute("rel") ? a.getAttribute("rel") + " " : "") + "noopener");
      noopenerFixed += 1;
    });
    if (noopenerFixed > 0) {
      recordAutoFix({
        id: "noopener_added",
        title: `Added rel="noopener" to ${noopenerFixed} link${noopenerFixed === 1 ? "" : "s"}`,
        detail: 'Closes the window.opener hole on target="_blank" links'
      });
    }

    // 11. Meta refresh -- flagged, never removed (it might BE the routing)
    const refreshMeta = document.querySelector('meta[http-equiv="refresh" i]');
    if (refreshMeta) {
      AUTO_FIX.manual.push({
        id: "meta_refresh_manual",
        title: "Meta refresh redirects this page",
        detail: "Replace with a server-side 301; the extension will not remove routing it does not own."
      });
    }

    const after = runLiveAudit();
    lastFixResult = {
      applied: AUTO_FIX.applied.slice(),
      skipped: AUTO_FIX.skipped.slice(),
      manual: AUTO_FIX.manual.slice(),
      scoreBefore: before.score,
      scoreAfter: after.score
    };
    return lastFixResult;
  }

  /**
   * Serialize the ORIGINAL HTML with head-level corrections folded in.
   * The live DOM is never serialized: at this point it contains the pill,
   * drawer, defect boxes and any framework-rendered nodes, none of which
   * belong in a file the user will deploy. Body content ships as-authored.
   */
  function generateCorrectedHtml() {
    // Serialize a CLEAN copy of the page: the live DOM carries the pill,
    // drawer and defect boxes, none of which belong in a deployable file.
    const clone = document.documentElement.cloneNode(true);
    clone.querySelectorAll('[id^="rankace-"], [class*="rankace-"]').forEach((el) => el.remove());

    // A downloaded HTML snapshot is opened from file:// (or a blob URL), so
    // root-relative app assets such as Next.js's /_next/static/*.js and images
    // would otherwise resolve against the local file instead of the page's
    // origin. Preserve the source base for assets that were not inlined above.
    const exportHead = clone.querySelector("head");
    if (exportHead) {
      try {
        let sourceBase = new URL(document.baseURI);
        if (!/^https?:$/.test(sourceBase.protocol) && location.origin && location.origin !== "null") {
          sourceBase = new URL("/", location.origin);
        }
        if (/^https?:$/.test(sourceBase.protocol)) {
          sourceBase.hash = "";
          let baseElement = exportHead.querySelector("base");
          if (!baseElement) {
            baseElement = document.createElement("base");
            exportHead.insertBefore(baseElement, exportHead.firstChild);
          }
          baseElement.setAttribute("href", sourceBase.href);
        }
      } catch (err) {
        // Keep the HTML export available for documents with opaque/no origin;
        // they have no external page root to preserve.
      }
    }

    // Inline stylesheets the page is allowed to read. A downloaded snapshot
    // must not depend on a development server still being online just to keep
    // its layout; CSSOM access is same-origin by design, while cross-origin
    // sheets stay linked below and are resolved through the preserved base.
    const originalStyleLinks = Array.from(document.querySelectorAll('link[rel~="stylesheet"]'));
    const clonedStyleLinks = Array.from(clone.querySelectorAll('link[rel~="stylesheet"]'));
    Array.from(document.styleSheets).forEach((sheet) => {
      const owner = sheet.ownerNode;
      if (!owner || owner.tagName !== "LINK" || sheet.disabled) return;
      const index = originalStyleLinks.indexOf(owner);
      const clonedLink = index >= 0 ? clonedStyleLinks[index] : null;
      if (!clonedLink || clonedLink.hasAttribute("disabled")) return;

      try {
        const rules = Array.from(sheet.cssRules);
        if (rules.length === 0) return;
        const stylesheetUrl = sheet.href || owner.href || document.baseURI;
        const cssText = rules
          .map((rule) => rule.cssText)
          .join("\n")
          .replace(/url\(\s*(?:(['\"])(.*?)\1|([^)]*?))\s*\)/gi, (match, quote, quoted, unquoted) => {
            const value = (quoted ?? unquoted ?? "").trim();
            if (!value || /^[a-z][a-z0-9+.-]*:/i.test(value) || value.startsWith("#")) return match;
            try {
              const absolute = new URL(value, stylesheetUrl).href.replace(/[\\\"\n\r]/g, "\\$&");
              return `url(\"${absolute}\")`;
            } catch (err) {
              return match;
            }
          })
          .replace(/<\/style/gi, "<\\/style");
        const inlineStyle = document.createElement("style");
        if (clonedLink.media) inlineStyle.media = clonedLink.media;
        if (clonedLink.nonce) inlineStyle.nonce = clonedLink.nonce;
        inlineStyle.textContent = cssText;
        clonedLink.replaceWith(inlineStyle);
      } catch (err) {
        // CSSOM blocks cross-origin sheets; keep the original link so it can
        // still load from its absolute URL when the source site is available.
      }
    });

    const fixes = [];

    // Body-level corrections ride along in the export too, so the file is
    // fully corrected even if the user never pressed "Fix all" first.
    let demoted = 0;
    Array.from(clone.querySelectorAll("h1")).forEach((el, idx) => {
      if (idx === 0) return;
      const tag = document.createElement("h2");
      while (el.firstChild) tag.appendChild(el.firstChild);
      Array.from(el.attributes).forEach((attr) => {
        if (attr.name !== "class" && attr.name !== "id") tag.setAttribute(attr.name, attr.value);
      });
      if (el.className) tag.setAttribute("class", el.className);
      if (el.parentNode) el.parentNode.replaceChild(tag, el);
      demoted += 1;
    });
    if (demoted) fixes.push(`Demoted ${demoted} duplicate <h1> to <h2>`);

    let altFilled = 0;
    Array.from(clone.querySelectorAll("img")).forEach((img) => {
      if (img.getAttribute("role") === "presentation" || img.getAttribute("role") === "none" || img.getAttribute("aria-hidden") === "true") return;
      if (img.hasAttribute("alt") && (img.getAttribute("alt") || "").trim()) return;
      const guess = deriveAltText(img);
      if (guess || img.hasAttribute("alt")) {
        img.setAttribute("alt", guess);
        altFilled += 1;
      }
    });
    if (altFilled) fixes.push(`Filled alt text on ${altFilled} image${altFilled === 1 ? "" : "s"}`);

    let noopener = 0;
    Array.from(clone.querySelectorAll('a[target="_blank"]')).forEach((a) => {
      const rel = (a.getAttribute("rel") || "").toLowerCase();
      if (rel.includes("noopener") || rel.includes("noreferrer")) return;
      a.setAttribute("rel", (a.getAttribute("rel") ? a.getAttribute("rel") + " " : "") + "noopener");
      noopener += 1;
    });
    if (noopener) fixes.push(`Added rel="noopener" to ${noopener} link${noopener === 1 ? "" : "s"}`);

    if (!exportHead) return { html: null, note: "No <head> found in document" };

    // Apply head and <html> corrections directly on the cloned DOM rather than
    // regex-replacing <head>...</head>, so inline scripts containing literal
    // "</head>" text or duplicate attribute strings cannot corrupt the output.
    const existingTitleEl = exportHead.querySelector("title");
    const existingTitleText = existingTitleEl ? (existingTitleEl.textContent || "").trim() : "";
    if (!existingTitleText) {
      const derivedTitle = ((clone.querySelector("h1") || {}).textContent || "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 60);
      if (derivedTitle) {
        const titleEl = existingTitleEl || document.createElement("title");
        titleEl.textContent = derivedTitle;
        if (!existingTitleEl) exportHead.appendChild(titleEl);
        fixes.push("Added <title>");
      }
    }

    const existingDescEl = exportHead.querySelector('meta[name="description" i]');
    const existingDescText = existingDescEl ? (existingDescEl.getAttribute("content") || "").trim() : "";
    if (!existingDescText) {
      const probe = clone.cloneNode(true);
      probe.querySelectorAll("script,style,noscript").forEach((el) => el.remove());
      const derivedDesc = ((probe.querySelector("body") || {}).textContent || "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 155);
      if (derivedDesc) {
        const descEl = existingDescEl || document.createElement("meta");
        descEl.setAttribute("name", "description");
        descEl.setAttribute("content", derivedDesc);
        if (!existingDescEl) exportHead.appendChild(descEl);
        fixes.push("Added meta description");
      }
    }

    if (!exportHead.querySelector('meta[name="viewport" i]')) {
      const vp = document.createElement("meta");
      vp.setAttribute("name", "viewport");
      vp.setAttribute("content", "width=device-width, initial-scale=1");
      exportHead.appendChild(vp);
      fixes.push("Added viewport meta");
    }

    if (!exportHead.querySelector("meta[charset]")) {
      const cs = document.createElement("meta");
      cs.setAttribute("charset", "utf-8");
      exportHead.insertBefore(cs, exportHead.firstChild);
      fixes.push("Added charset");
    }

    const canonicalEl = exportHead.querySelector('link[rel="canonical"]');
    const canonicalHref = canonicalEl ? (canonicalEl.getAttribute("href") || "").trim() : "";
    if (!canonicalHref && location.protocol.startsWith("http")) {
      const link = canonicalEl || document.createElement("link");
      link.setAttribute("rel", "canonical");
      link.setAttribute("href", location.href.split("#")[0]);
      if (!canonicalEl) exportHead.appendChild(link);
      fixes.push("Added canonical");
    }

    const robotsMetaEl = exportHead.querySelector('meta[name="robots" i]');
    if (robotsMetaEl) {
      const content = (robotsMetaEl.getAttribute("content") || "").trim();
      const cleaned = content
        .split(",")
        .map((d) => d.trim())
        .filter((d) => !/^(noindex|none)$/i.test(d))
        .join(", ");
      if (cleaned !== content) {
        robotsMetaEl.setAttribute("content", cleaned);
        fixes.push("Removed noindex");
      }
    }

    if (!(clone.getAttribute("lang") || "").trim()) {
      const langAttr = (navigator.language || "en").toLowerCase();
      clone.setAttribute("lang", langAttr);
      fixes.push("Declared <html lang>");
    }

    let html = clone.outerHTML;
    if (!/^\s*<!doctype/i.test(html)) html = "<!doctype html>\n" + html;

    if (fixes.length === 0) {
      fixes.push("Page already corrected in this tab — exporting the fixed version");
    }
    return { html, fixes: fixes.filter(Boolean) };
  }

  function downloadCorrectedHtml() {
    const { html, fixes, note } = generateCorrectedHtml();
    if (!html) {
      return { ok: false, note: note || "Could not build a corrected file" };
    }
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${slugify(document.title || location.pathname)}-rankace-fixed.html`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return { ok: true, fixes: fixes || [], filename: a.download, bytes: html.length };
  }

  // -------------------------------------------------------------
  // 5. KEYBOARD SHORTCUT (Alt+R) & MESSAGE LISTENERS
  // -------------------------------------------------------------
  window.addEventListener("keydown", (e) => {
    // Alt+R or Option+R toggles in-page assistant drawer and boxes
    if (e.altKey && (e.key === "r" || e.key === "R")) {
      e.preventDefault();
      toggleInPageDrawer();
    }
    // Esc closes drawer
    if (e.key === "Escape" && drawerOpen) {
      toggleInPageDrawer(false);
    }
  });

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "ONE_CLICK_ACTIVATE") {
      toggleInPageDrawer(true);
      sendResponse({ success: true, opened: true });
      return true;
    }

    if (request.action === "GET_LIVE_AUDIT") {
      const data = runLiveAudit();
      sendResponse(data);
      return true;
    }

    if (request.action === "HIGHLIGHT_DEFECT") {
      const success = highlightSingleElement(request.targetSelector, request.issue);
      sendResponse({ success });
      return true;
    }

    if (request.action === "HIGHLIGHT_ALL") {
      isInspectionEnabled = !!request.enable;
      if (request.enable) {
        const count = highlightAllIssuesOnPage(request.issues || (cachedAuditData ? cachedAuditData.issues : []));
        sendResponse({ highlightedCount: count, enabled: true });
      } else {
        clearAllHighlights();
        sendResponse({ cleared: true, enabled: false });
      }
      return true;
    }

    if (request.action === "CLEAR_HIGHLIGHTS") {
      clearAllHighlights();
      sendResponse({ success: true });
      return true;
    }

    if (request.action === "TOGGLE_FLOATING_ASSISTANT") {
      toggleInPageDrawer();
      sendResponse({ success: true });
      return true;
    }

    if (request.action === "HIGHLIGHT_NOFOLLOW") {
      clearAllHighlights();
      const nofollowIssues = Array.from(document.querySelectorAll('a[href]'))
        .filter((a) => ((a.getAttribute("rel") || "").toLowerCase().includes("nofollow")))
        .map((a, idx) => ({
          id: `nofollow_${idx}`,
          category: "Links",
          severity: "info",
          title: "Nofollow link",
          message: `Link to ${(a.getAttribute("href") || "").slice(0, 80)} carries rel=nofollow, so no link equity passes.`,
          recommendation: "Remove nofollow if this is an endorsement you want counted.",
          targetSelector: getElementPath(a)
        }));
      let drawn = 0;
      nofollowIssues.forEach((issue) => {
        if (issue.targetSelector && createBoundingBox(document.querySelector(issue.targetSelector), issue)) drawn += 1;
      });
      isInspectionEnabled = true;
      sendResponse({ highlightedCount: drawn, total: nofollowIssues.length });
      return true;
    }

    if (request.action === "APPLY_ALL_FIXES") {
      const result = applyAllFixes();
      if (drawerOpen) {
        renderDrawerContent(runLiveAudit(), result);
        highlightAllIssuesOnPage(cachedAuditData ? cachedAuditData.issues : []);
      }
      sendResponse(result);
      return true;
    }

    if (request.action === "DOWNLOAD_CORRECTED_HTML") {
      sendResponse(downloadCorrectedHtml());
      return true;
    }

    if (request.action === "GENERATE_CORRECTED_HTML") {
      const { html, fixes, note } = generateCorrectedHtml();
      sendResponse(html ? { ok: true, html, fixes: fixes || [] } : { ok: false, note: note || "No changes needed" });
      return true;
    }

    if (request.action === "APPLY_CUSTOM_META") {
      const nextTitle = typeof request.title === "string" ? request.title.trim() : "";
      const nextDesc = typeof request.description === "string" ? request.description.trim() : "";
      if (nextTitle) document.title = nextTitle;
      if (nextDesc) {
        const meta = ensureMetaByName("description");
        meta.setAttribute("content", nextDesc);
      }
      const audit = runLiveAudit();
      if (drawerOpen) {
        renderDrawerContent(audit, null);
        if (isInspectionEnabled) highlightAllIssuesOnPage(audit.issues);
      }
      sendResponse({ ok: true, audit });
      return true;
    }

    if (request.action === "INJECT_JSONLD") {
      try {
        const raw = typeof request.jsonLd === "string" ? request.jsonLd : JSON.stringify(request.jsonLd, null, 2);
        const parsed = JSON.parse(raw);
        const script = document.createElement("script");
        script.type = "application/ld+json";
        script.dataset.rankaceGenerated = "1";
        script.textContent = JSON.stringify(parsed, null, 2);
        ensureHead().appendChild(script);
        const audit = runLiveAudit();
        if (drawerOpen) renderDrawerContent(audit, null);
        sendResponse({ ok: true, audit });
      } catch (err) {
        sendResponse({ ok: false, error: err.message || "Invalid JSON-LD" });
      }
      return true;
    }
  });

  // -------------------------------------------------------------
  // 6. SCROLL & LIVE CHANGE TRACKING ENGINE
  // -------------------------------------------------------------
  
  // A. Scroll Sync (Capture listener catches scrolls in window, body, & inner overflow divs)
  let isScrollThrottled = false;
  window.addEventListener("scroll", () => {
    if (!isScrollThrottled) {
      window.requestAnimationFrame(() => {
        repositionAllBoxes();
        isScrollThrottled = false;
      });
      isScrollThrottled = true;
    }
  }, { capture: true, passive: true });

  // B. Window Resize Sync
  window.addEventListener("resize", () => {
    window.requestAnimationFrame(repositionAllBoxes);
  }, { passive: true });

  // C. Live DOM MutationObserver (Updates live when page elements/attributes change)
  let mutationDebounceTimer = null;
  const domObserver = new MutationObserver((mutations) => {
    // Prevent infinite recursion from Rankace's own DOM updates
    const isSelfMutation = mutations.every(m => {
      const node = m.target;
      return node && (
        node.id === "rankace-inpage-drawer" ||
        node.id === "rankace-floating-pill" ||
        (node.classList && (node.classList.contains("rankace-defect-box") || node.classList.contains("rankace-defect-callout"))) ||
        (node.closest && (node.closest("#rankace-inpage-drawer") || node.closest(".rankace-defect-box") || node.closest("#rankace-floating-pill")))
      );
    });
    if (isSelfMutation) return;

    clearTimeout(mutationDebounceTimer);
    mutationDebounceTimer = setTimeout(() => {
      const prevSig = cachedAuditData
        ? `${cachedAuditData.score}:${cachedAuditData.issues.length}:${cachedAuditData.title}:${cachedAuditData.url}`
        : "";
      const audit = runLiveAudit();
      const nextSig = `${audit.score}:${audit.issues.length}:${audit.title}:${audit.url}`;
      if (drawerOpen) {
        if (nextSig !== prevSig) {
          const bodyEl = document.getElementById("rankace-drawer-body");
          const prevScroll = bodyEl ? bodyEl.scrollTop : 0;
          renderDrawerContent(audit);
          const nextBodyEl = document.getElementById("rankace-drawer-body");
          if (nextBodyEl) nextBodyEl.scrollTop = prevScroll;
        }
        const toggle = document.getElementById("rankace-drawer-toggle-boxes");
        if (!toggle || toggle.checked) {
          highlightAllIssuesOnPage(audit.issues);
        }
      } else if (allHighlighted) {
        highlightAllIssuesOnPage(audit.issues);
      } else {
        repositionAllBoxes();
      }
    }, 400);
  });

  if (document.body) {
    domObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["alt", "src", "href", "title", "class", "style"]
    });
  }

  // D. Live SPA Navigation Tracker (Next.js, React, Vue, client-side route changes)
  let currentTrackedUrl = location.href;
  function handleUrlChange() {
    if (location.href !== currentTrackedUrl) {
      currentTrackedUrl = location.href;
      clearAllHighlights();
      setTimeout(() => {
        const audit = runLiveAudit();
        if (drawerOpen) {
          renderDrawerContent(audit);
          highlightAllIssuesOnPage(audit.issues);
        }
      }, 350);
    }
  }

  window.addEventListener("popstate", handleUrlChange);
  window.addEventListener("hashchange", handleUrlChange);

  const _origPushState = history.pushState;
  history.pushState = function () {
    _origPushState.apply(this, arguments);
    handleUrlChange();
  };

  const _origReplaceState = history.replaceState;
  history.replaceState = function () {
    _origReplaceState.apply(this, arguments);
    handleUrlChange();
  };

  // Initial silent audit to display floating pill
  setTimeout(runLiveAudit, 600);
})();
